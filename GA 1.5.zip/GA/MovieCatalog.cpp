#include "MovieCatalog.h"
#include "Ticket.h"

#include <iostream>

using namespace std;

const int CatalogMenuWidth = 100;

// Print catalog headings using the same 100-character style as the main menus.
void printCatalogSeparator() {
    cout << string(CatalogMenuWidth, '-') << endl;
}

void printCatalogTitle(const string& title) {
    int leftPadding = (CatalogMenuWidth - static_cast<int>(title.length())) / 2;
    if (leftPadding < 0) {
        leftPadding = 0;
    }
    cout << string(leftPadding, ' ') << title << endl;
}

// Wrap long catalog lines so text does not run past the 60-character menu width.
void printWrappedCatalogLine(const string& firstPrefix, const string& nextPrefix, const string& text) {
    string remainingText = text;
    string currentPrefix = firstPrefix;

    while (!remainingText.empty()) {
        int availableWidth = CatalogMenuWidth - static_cast<int>(currentPrefix.length());
        if (availableWidth < 10) {
            availableWidth = 10;
        }

        if (static_cast<int>(remainingText.length()) <= availableWidth) {
            cout << currentPrefix << remainingText << endl;
            return;
        }

        size_t breakPosition = remainingText.rfind(' ', availableWidth);
        if (breakPosition == string::npos || breakPosition == 0) {
            breakPosition = availableWidth;
        }

        cout << currentPrefix << remainingText.substr(0, breakPosition) << endl;
        while (breakPosition < remainingText.length()
               && remainingText[breakPosition] == ' ') {
            breakPosition++;
        }
        remainingText = remainingText.substr(breakPosition);
        currentPrefix = nextPrefix;
    }
}

// Wrap screening slots without splitting one "Hall X (HH:MM)" item across lines.
void printWrappedTimeSlot(const string& prefix, const string& nextPrefix, const string& slotText,
                          bool& lineStarted, int& currentLineLength) {
    if (!lineStarted) {
        cout << prefix << slotText;
        lineStarted = true;
        currentLineLength = static_cast<int>(prefix.length() + slotText.length());
        return;
    }

    string itemText = ", " + slotText;
    if (currentLineLength + static_cast<int>(itemText.length()) > CatalogMenuWidth) {
        cout << "," << endl;
        cout << nextPrefix << slotText;
        currentLineLength = static_cast<int>(nextPrefix.length() + slotText.length());
    } else {
        cout << itemText;
        currentLineLength += static_cast<int>(itemText.length());
    }
}

// Constructor loads default movie data when the system starts.
MovieCatalog::MovieCatalog()
    : movieCount(0) {
}

// Staff summary view: group repeated screenings under the same movie title.
void MovieCatalog::showMovieSummary() const {
    cout << endl;
    printCatalogSeparator();
    printCatalogTitle("Movie List");
    printCatalogSeparator();
    if (movieCount == 0) {
        cout << "No movies available." << endl;
        return;
    }

    int displayNumber = 1;
    for (int index = 0; index < movieCount; ++index) {
        if (movieTitleAppearedBefore(index)) {
            continue;
        }

        printWrappedCatalogLine(to_string(displayNumber) + ". ", "   ", movies[index]);
        string movieDetails = genres[index] + " | " + classifications[index]
            + " | " + languages[index] + " | Duration: " + durations[index];
        printWrappedCatalogLine("   Genre: ", "          ", movieDetails);

        bool lineStarted = false;
        int currentLineLength = 0;
        for (int slotIndex = 0; slotIndex < movieCount; ++slotIndex) {
            if (toLowerText(movies[slotIndex]) == toLowerText(movies[index])) {
                string slotText = halls[slotIndex] + " (" + showTimes[slotIndex] + ")";
                printWrappedTimeSlot("   Time Slots: ", "               ", slotText, lineStarted, currentLineLength);
            }
        }
        cout << endl;
        displayNumber++;
    }
}

// Staff edit/delete view: display every screening separately with its internal number.
void MovieCatalog::showMovies() const {
    cout << endl;
    printCatalogSeparator();
    printCatalogTitle("Screening List");
    printCatalogSeparator();
    if (movieCount == 0) {
        cout << "No movies available." << endl;
        return;
    }

    for (int index = 0; index < movieCount; ++index) {
        cout << index + 1 << ". " << movies[index] << " | " << showTimes[index]
             << " | " << halls[index] << endl;
        cout << "   Genre: " << genres[index]
             << " | Classification: " << classifications[index]
             << " | Language: " << languages[index]
             << " | Duration: " << durations[index] << endl;
    }
}

// Check whether the movie title already appeared earlier in the screening array.
bool MovieCatalog::movieTitleAppearedBefore(int currentIndex) const {
    for (int index = 0; index < currentIndex; ++index) {
        if (toLowerText(movies[index]) == toLowerText(movies[currentIndex])) {
            return true;
        }
    }
    return false;
}

// Customer view: display today's unique movies with details, but not hall allocation.
void MovieCatalog::showTodaysMovies() const {
    cout << endl;
    printCatalogSeparator();
    printCatalogTitle("Today's Movies");
    printCatalogSeparator();
    if (movieCount == 0) {
        cout << "No movies available today." << endl;
        return;
    }

    int displayNumber = 1;
    for (int index = 0; index < movieCount; ++index) {
        if (movieTitleAppearedBefore(index)) {
            continue;
        }
        cout << displayNumber << ". " << movies[index] << endl;
        cout << "   Genre: " << genres[index]
             << " | " << classifications[index]
             << " | " << languages[index]
             << " | Duration: " << durations[index] << endl;
        displayNumber++;
    }
}

// Display only the showtimes for one selected movie.
void MovieCatalog::showShowtimesForMovie(const string& movieTitle) const {
    cout << endl;
    printCatalogSeparator();
    printCatalogTitle("Showtimes");
    printCatalogSeparator();
    printCatalogTitle(movieTitle);
    int displayNumber = 1;
    for (int index = 0; index < movieCount; ++index) {
        if (toLowerText(movies[index]) == toLowerText(movieTitle)) {
            cout << displayNumber << ". " << showTimes[index]
                 << " (" << durations[index] << ")" << endl;
            displayNumber++;
        }
    }
    if (displayNumber == 1) {
        cout << "No showtimes available for this movie." << endl;
    }
}

// Add a new screening into the catalog array if there is space and no duplicate screening.
bool MovieCatalog::addMovie(const string& movieTitle, const string& genre, const string& classification,
                            const string& language, const string& duration, const string& hallName, const string& showTime) {
    if (movieCount >= MaxMovies) {
        cout << "Cannot add movie: movie catalog is full." << endl;
        return false;
    }
    if (hallShowtimeExists(hallName, showTime)) {
        cout << "Cannot add movie: " << hallName << " already has a screening at "
             << showTime << "." << endl;
        return false;
    }
    if (screeningExists(movieTitle, hallName, showTime)) {
        cout << "Cannot add movie: same movie, hall, and showtime already exists." << endl;
        return false;
    }

    movies[movieCount] = movieTitle;
    genres[movieCount] = genre;
    classifications[movieCount] = classification;
    languages[movieCount] = language;
    durations[movieCount] = duration;
    halls[movieCount] = hallName;
    showTimes[movieCount] = showTime;
    movieCount++;
    return true;
}

// Update one screening without changing the array position.
bool MovieCatalog::updateMovie(int movieNumber, const string& movieTitle, const string& genre, const string& classification,
                               const string& language, const string& duration, const string& hallName, const string& showTime) {
    if (!isValidMovieNumber(movieNumber)) {
        cout << "Invalid movie number. Please select from the movie list." << endl;
        return false;
    }

    if (hallShowtimeTakenByOtherScreening(movieNumber, hallName, showTime)) {
        cout << "Cannot update movie: " << hallName << " already has a screening at "
             << showTime << "." << endl;
        return false;
    }

    int updateIndex = movieNumber - 1;
    movies[updateIndex] = movieTitle;
    genres[updateIndex] = genre;
    classifications[updateIndex] = classification;
    languages[updateIndex] = language;
    durations[updateIndex] = duration;
    halls[updateIndex] = hallName;
    showTimes[updateIndex] = showTime;
    return true;
}

// Delete a movie by shifting later array elements one position to the left.
bool MovieCatalog::removeMovie(int movieNumber) {
    if (!isValidMovieNumber(movieNumber)) {
        cout << "Invalid movie number. Please select from the movie list." << endl;
        return false;
    }

    int removeIndex = movieNumber - 1;
    for (int index = removeIndex; index < movieCount - 1; ++index) {
        movies[index] = movies[index + 1];
        genres[index] = genres[index + 1];
        classifications[index] = classifications[index + 1];
        languages[index] = languages[index + 1];
        durations[index] = durations[index + 1];
        halls[index] = halls[index + 1];
        showTimes[index] = showTimes[index + 1];
    }
    movieCount--;
    return true;
}

// Reset the catalog before loading movie data from a text file.
void MovieCatalog::clearMovies() {
    movieCount = 0;
}

// Check whether a selected movie number is inside the valid range.
bool MovieCatalog::isValidMovieNumber(int movieNumber) const {
    return movieNumber >= 1 && movieNumber <= movieCount;
}

// Check whether a unique movie number is valid in the customer movie list.
bool MovieCatalog::isValidUniqueMovieNumber(int movieNumber) const {
    return isValidText(getUniqueMovieTitle(movieNumber));
}

// Case-insensitive duplicate screening check.
bool MovieCatalog::screeningExists(const string& movieTitle, const string& hallName, const string& showTime) const {
    for (int index = 0; index < movieCount; ++index) {
        if (toLowerText(movies[index]) == toLowerText(movieTitle)
            && toLowerText(halls[index]) == toLowerText(hallName)
            && toLowerText(showTimes[index]) == toLowerText(showTime)) {
            return true;
        }
    }
    return false;
}

// Check whether a hall is already occupied at the selected showtime.
bool MovieCatalog::hallShowtimeExists(const string& hallName, const string& showTime) const {
    for (int index = 0; index < movieCount; ++index) {
        if (toLowerText(halls[index]) == toLowerText(hallName)
            && toLowerText(showTimes[index]) == toLowerText(showTime)) {
            return true;
        }
    }
    return false;
}

// Edit validation: ignore the current screening but check all other screenings.
bool MovieCatalog::hallShowtimeTakenByOtherScreening(int movieNumber, const string& hallName, const string& showTime) const {
    int currentIndex = movieNumber - 1;
    for (int index = 0; index < movieCount; ++index) {
        if (index != currentIndex
            && toLowerText(halls[index]) == toLowerText(hallName)
            && toLowerText(showTimes[index]) == toLowerText(showTime)) {
            return true;
        }
    }
    return false;
}

// Return the movie title from the unique customer movie list.
string MovieCatalog::getUniqueMovieTitle(int movieNumber) const {
    if (movieNumber <= 0) {
        return "";
    }

    int displayNumber = 0;
    for (int index = 0; index < movieCount; ++index) {
        if (movieTitleAppearedBefore(index)) {
            continue;
        }
        displayNumber++;
        if (displayNumber == movieNumber) {
            return movies[index];
        }
    }
    return "";
}

// Convert a selected showtime number for one movie into the real screening number.
int MovieCatalog::getScreeningNumberForMovieShowtime(const string& movieTitle, int showtimeNumber) const {
    if (showtimeNumber <= 0) {
        return 0;
    }

    int displayNumber = 0;
    for (int index = 0; index < movieCount; ++index) {
        if (toLowerText(movies[index]) == toLowerText(movieTitle)) {
            displayNumber++;
            if (displayNumber == showtimeNumber) {
                return index + 1;
            }
        }
    }
    return 0;
}

string MovieCatalog::getMovieTitle(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return movies[movieNumber - 1];
}

string MovieCatalog::getGenre(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return genres[movieNumber - 1];
}

string MovieCatalog::getClassification(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return classifications[movieNumber - 1];
}

string MovieCatalog::getLanguage(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return languages[movieNumber - 1];
}

string MovieCatalog::getDuration(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return durations[movieNumber - 1];
}

string MovieCatalog::getHallName(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return halls[movieNumber - 1];
}

string MovieCatalog::getShowTime(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return showTimes[movieNumber - 1];
}

bool MovieCatalog::findMovieDetailsByTitle(const string& movieTitle, string& genre, string& classification,
                                           string& language, string& hallName, string& showTime) const {
    for (int index = 0; index < movieCount; ++index) {
        if (toLowerText(movies[index]) == toLowerText(movieTitle)) {
            genre = genres[index];
            classification = classifications[index];
            language = languages[index];
            hallName = halls[index];
            showTime = showTimes[index];
            return true;
        }
    }
    return false;
}

int MovieCatalog::getMovieCount() const {
    return movieCount;
}
