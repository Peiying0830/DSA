#include "CancelLog.h"

using namespace std;

CancelLog::CancelLog()
    : topIndex(-1) {
}

// Push a cancellation record onto the stack.
bool CancelLog::recordCancel(const CancelEntry& entry) {
    if (isFull()) {
        cout << "Cannot record cancellation: cancel log is full." << endl;
        return false;
    }

    topIndex++;
    entries[topIndex] = entry;
    cout << "Cancellation recorded: Ticket #" << entry.ticketID << " at " << entry.cancelledAt << "." << endl;
    return true;
}

// Pop the latest cancellation record for undo operation.
bool CancelLog::undoCancel(CancelEntry& entry) {
    if (isEmpty()) {
        cout << "No cancellations to undo." << endl;
        return false;
    }

    entry = entries[topIndex];
    topIndex--;
    cout << "Undoing cancellation for Ticket #" << entry.ticketID << "." << endl;
    return true;
}

// View the latest cancellation without removing it from the stack.
bool CancelLog::peekLatest(CancelEntry& entry) const {
    if (isEmpty()) {
        cout << "No cancellations available to peek." << endl;
        return false;
    }

    entry = entries[topIndex];
    cout << "Latest cancellation: Ticket #" << entry.ticketID << " | " << entry.customerName
              << " | " << entry.note << " | " << entry.cancelledAt << endl;
    return true;
}

// Display cancellation records from newest to oldest.
void CancelLog::showAllCancels() const {
    if (isEmpty()) {
        cout << "Cancellation log is empty." << endl;
        return;
    }

    cout << "Cancellation log (most recent first):" << endl;
    for (int index = topIndex; index >= 0; --index) {
        const CancelEntry& entry = entries[index];
        cout << "  Ticket #" << entry.ticketID << " | " << entry.customerName
                  << " | " << entry.note << " | " << entry.cancelledAt << endl;
    }
}

bool CancelLog::isEmpty() const {
    return topIndex < 0;
}

bool CancelLog::isFull() const {
    return topIndex >= MaxCapacity - 1;
}

int CancelLog::getCount() const {
    return topIndex + 1;
}
