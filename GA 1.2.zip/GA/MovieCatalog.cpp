#include "MovieCatalog.h"
#include "Ticket.h"

#include <iostream>

using namespace std;

// Constructor loads default movie data when the system starts.
MovieCatalog::MovieCatalog()
    : movieCount(0) {
    addMovie("Spider-Man: Brand New Day", "Action / Superhero", "P12", "English", "Hall 1", "10:00 AM");
    addMovie("Inside Out 2", "Animation / Family", "U", "English", "Hall 2", "12:30 PM");
    addMovie("The Conjuring", "Horror / Supernatural", "P18", "English", "Hall 3", "3:00 PM");
    addMovie("Hi", "Drama / Romance", "P13", "Tamil", "Hall 4", "5:30 PM");
    addMovie("Kung Fu Soccer", "Action / Comedy", "P12", "Mandarin", "Hall 5", "8:00 PM");
    addMovie("Possessed", "Horror", "P16", "Thai", "Hall 6", "10:30 PM");
}

// Display all movies with hall and showtime.
void MovieCatalog::showMovies() const {
    cout << "\nAvailable Movies" << endl;
    if (movieCount == 0) {
        cout << "No movies available." << endl;
        return;
    }

    for (int index = 0; index < movieCount; ++index) {
        cout << index + 1 << ". " << movies[index] << " (" << halls[index]
             << ", " << showTimes[index] << ")" << endl;
        cout << "   Genre: " << genres[index]
             << " | Classification: " << classifications[index]
             << " | Language: " << languages[index] << endl;
    }
}

// Display a customer-friendly list of today's showtimes.
void MovieCatalog::showTodaysShowtimes() const {
    cout << "\nToday's Showtimes" << endl;
    if (movieCount == 0) {
        cout << "No showtimes available today." << endl;
        return;
    }

    for (int index = 0; index < movieCount; ++index) {
        cout << index + 1 << ". " << movies[index]
             << " | " << halls[index]
             << " | " << showTimes[index]
             << " | " << genres[index]
             << " | " << classifications[index]
             << " | " << languages[index] << endl;
    }
}

// Add a new movie into the catalog array if there is space and no duplicate title.
bool MovieCatalog::addMovie(const string& movieTitle, const string& genre, const string& classification,
                            const string& language, const string& hallName, const string& showTime) {
    if (movieCount >= MaxMovies) {
        cout << "Cannot add movie: movie catalog is full." << endl;
        return false;
    }
    if (movieTitleExists(movieTitle)) {
        cout << "Cannot add movie: movie title already exists." << endl;
        return false;
    }

    movies[movieCount] = movieTitle;
    genres[movieCount] = genre;
    classifications[movieCount] = classification;
    languages[movieCount] = language;
    halls[movieCount] = hallName;
    showTimes[movieCount] = showTime;
    movieCount++;
    return true;
}

// Delete a movie by shifting later array elements one position to the left.
bool MovieCatalog::removeMovie(int movieNumber) {
    if (!isValidMovieNumber(movieNumber)) {
        cout << "Invalid movie number. Please select from the movie list." << endl;
        return false;
    }

    int removeIndex = movieNumber - 1;
    for (int index = removeIndex; index < movieCount - 1; ++index) {
        movies[index] = movies[index + 1];
        genres[index] = genres[index + 1];
        classifications[index] = classifications[index + 1];
        languages[index] = languages[index + 1];
        halls[index] = halls[index + 1];
        showTimes[index] = showTimes[index + 1];
    }
    movieCount--;
    return true;
}

// Reset the catalog before loading movie data from a text file.
void MovieCatalog::clearMovies() {
    movieCount = 0;
}

// Check whether a selected movie number is inside the valid range.
bool MovieCatalog::isValidMovieNumber(int movieNumber) const {
    return movieNumber >= 1 && movieNumber <= movieCount;
}

// Case-insensitive duplicate movie title check.
bool MovieCatalog::movieTitleExists(const string& movieTitle) const {
    for (int index = 0; index < movieCount; ++index) {
        if (toLowerText(movies[index]) == toLowerText(movieTitle)) {
            return true;
        }
    }
    return false;
}

string MovieCatalog::getMovieTitle(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return movies[movieNumber - 1];
}

string MovieCatalog::getGenre(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return genres[movieNumber - 1];
}

string MovieCatalog::getClassification(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return classifications[movieNumber - 1];
}

string MovieCatalog::getLanguage(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return languages[movieNumber - 1];
}

string MovieCatalog::getHallName(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return halls[movieNumber - 1];
}

string MovieCatalog::getShowTime(int movieNumber) const {
    if (!isValidMovieNumber(movieNumber)) {
        return "";
    }
    return showTimes[movieNumber - 1];
}

bool MovieCatalog::findMovieDetailsByTitle(const string& movieTitle, string& genre, string& classification,
                                           string& language, string& hallName, string& showTime) const {
    for (int index = 0; index < movieCount; ++index) {
        if (toLowerText(movies[index]) == toLowerText(movieTitle)) {
            genre = genres[index];
            classification = classifications[index];
            language = languages[index];
            hallName = halls[index];
            showTime = showTimes[index];
            return true;
        }
    }
    return false;
}

int MovieCatalog::getMovieCount() const {
    return movieCount;
}
