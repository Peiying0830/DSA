#ifndef MOVIE_CATALOG_H
#define MOVIE_CATALOG_H

#include <string>

using namespace std;

// MovieCatalog stores the available movies using parallel arrays.
// This demonstrates array + count management.
class MovieCatalog {
public:
    // Maximum number of movies that can be stored in the catalog.
    static const int MaxMovies = 20;

    MovieCatalog();

    void showMovies() const;
    void showTodaysShowtimes() const;
    bool addMovie(const string& movieTitle, const string& genre, const string& classification,
                  const string& language, const string& hallName, const string& showTime);
    bool removeMovie(int movieNumber);
    void clearMovies();
    bool isValidMovieNumber(int movieNumber) const;
    bool movieTitleExists(const string& movieTitle) const;
    string getMovieTitle(int movieNumber) const;
    string getGenre(int movieNumber) const;
    string getClassification(int movieNumber) const;
    string getLanguage(int movieNumber) const;
    string getHallName(int movieNumber) const;
    string getShowTime(int movieNumber) const;
    bool findMovieDetailsByTitle(const string& movieTitle, string& genre, string& classification,
                                 string& language, string& hallName, string& showTime) const;
    int getMovieCount() const;

private:
    // Parallel arrays: the same index represents one movie's full information.
    string movies[MaxMovies];
    string genres[MaxMovies];
    string classifications[MaxMovies];
    string languages[MaxMovies];
    string halls[MaxMovies];
    string showTimes[MaxMovies];

    // Current number of movies stored in the arrays.
    int movieCount;
};

#endif // MOVIE_CATALOG_H
