#include "WaitingLine.h"

using namespace std;

WaitingLine::WaitingLine()
    : head(nullptr), tail(nullptr) {
}

WaitingLine::~WaitingLine() {
    clear();
}

// Add a ticket to the rear of the waiting line.
bool WaitingLine::joinLine(const Ticket& ticket) {
    if (contains(ticket.ticketID)) {
        cout << "Cannot join line: Ticket #" << ticket.ticketID << " is already in the waiting line." << endl;
        return false;
    }

    Node* newNode = new Node{ticket, nullptr};
    if (isEmpty()) {
        head = tail = newNode;
    } else {
        tail->next = newNode;
        tail = newNode;
    }

    cout << "Ticket #" << ticket.ticketID << " added to waiting line." << endl;
    return true;
}

// Remove the front ticket from the waiting line.
bool WaitingLine::serveNext(Ticket& servedTicket) {
    if (isEmpty()) {
        cout << "No customers to serve: the waiting line is empty." << endl;
        return false;
    }

    Node* current = head;
    servedTicket = current->ticket;
    head = head->next;
    if (head == nullptr) {
        tail = nullptr;
    }
    delete current;

    cout << "Serving Ticket #" << servedTicket.ticketID << ", customer " << servedTicket.customerName << "." << endl;
    return true;
}

// Display every customer currently in the queue from front to rear.
void WaitingLine::showLine() const {
    if (isEmpty()) {
        cout << "Waiting line is currently empty." << endl;
        return;
    }

    cout << "Current waiting line (front to rear):" << endl;
    Node* current = head;
    while (current != nullptr) {
        const Ticket& ticket = current->ticket;
        cout << "  Ticket #" << ticket.ticketID << " | " << ticket.customerName << " | "
                  << ticket.movieTitle << " | " << ticket.hallName << " | " << ticket.showTime << " | "
                  << ticket.seatCode << " | "
                  << ticket.ticketType << " | RM" << ticket.ticketPrice << " | "
                  << ticketStatusToString(ticket.status) << endl;
        current = current->next;
    }
}

// Peek at the front customer without removing them.
void WaitingLine::showFront() const {
    if (isEmpty()) {
        cout << "The waiting line is empty. No front customer." << endl;
        return;
    }

    const Ticket& ticket = head->ticket;
    cout << "Front of line: Ticket #" << ticket.ticketID << " | " << ticket.customerName
              << " | " << ticket.movieTitle << " | " << ticket.hallName << " | " << ticket.showTime
              << " | " << ticket.seatCode << " | "
              << ticket.ticketType << " | RM" << ticket.ticketPrice << " | "
              << ticketStatusToString(ticket.status) << endl;
}

// Peek at the rear customer without removing them.
void WaitingLine::showRear() const {
    if (isEmpty()) {
        cout << "The waiting line is empty. No rear customer." << endl;
        return;
    }

    const Ticket& ticket = tail->ticket;
    cout << "Rear of line: Ticket #" << ticket.ticketID << " | " << ticket.customerName
              << " | " << ticket.movieTitle << " | " << ticket.hallName << " | " << ticket.showTime
              << " | " << ticket.seatCode << " | "
              << ticket.ticketType << " | RM" << ticket.ticketPrice << " | "
              << ticketStatusToString(ticket.status) << endl;
}

bool WaitingLine::isEmpty() const {
    return head == nullptr;
}

bool WaitingLine::isFull() const {
    // Linked list queue has no fixed capacity, so it is never full.
    return false;
}

// Remove a specific waiting ticket when it is cancelled.
bool WaitingLine::removeTicketByID(int ticketID) {
    if (isEmpty()) {
        return false;
    }

    Node* current = head;
    Node* previous = nullptr;
    while (current != nullptr) {
        if (current->ticket.ticketID == ticketID) {
            if (previous == nullptr) {
                head = current->next;
            } else {
                previous->next = current->next;
            }

            if (current == tail) {
                tail = previous;
            }

            delete current;
            return true;
        }
        previous = current;
        current = current->next;
    }
    return false;
}

// Check if a ticket already exists in the queue.
bool WaitingLine::contains(int ticketID) const {
    Node* current = head;
    while (current != nullptr) {
        if (current->ticket.ticketID == ticketID) {
            return true;
        }
        current = current->next;
    }
    return false;
}

// Keep queue data consistent after staff edits a waiting ticket.
bool WaitingLine::updateTicketByID(const Ticket& ticket) {
    Node* current = head;
    while (current != nullptr) {
        if (current->ticket.ticketID == ticket.ticketID) {
            current->ticket = ticket;
            return true;
        }
        current = current->next;
    }
    return false;
}

// Public wrapper for clearing the queue when ticket data is loaded from file.
void WaitingLine::clearLine() {
    clear();
}

void WaitingLine::clear() {
    while (head != nullptr) {
        Node* current = head;
        head = head->next;
        delete current;
    }
    tail = nullptr;
}
