#include "Registry.h"

#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>

using namespace std;

Registry::Registry()
    : tickets(), ticketCount(0), waitingLine(), cancelLog(), movieCatalog() {
}

// Check duplicate ticket ID in the ticket registry array.
bool Registry::ticketIDExists(int ticketID) const {
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        if (ticket.ticketID == ticketID) {
            return true;
        }
    }
    return false;
}

// Check whether a seat is already taken in the same hall.
// Cancelled tickets are ignored because their seats become available again.
bool Registry::seatCodeTaken(const string& hallName, const string& seatCode) const {
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        if (toLowerText(ticket.hallName) == toLowerText(hallName)
            && toLowerText(ticket.seatCode) == toLowerText(seatCode)
            && ticket.status != TicketStatus::CANCELLED) {
            return true;
        }
    }
    return false;
}

// Used during edit operation to check seat duplication against other tickets only.
bool Registry::seatCodeTakenByOtherTicket(const string& hallName, const string& seatCode, int currentTicketID) const {
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        if (ticket.ticketID != currentTicketID
            && toLowerText(ticket.hallName) == toLowerText(hallName)
            && toLowerText(ticket.seatCode) == toLowerText(seatCode)
            && ticket.status != TicketStatus::CANCELLED) {
            return true;
        }
    }
    return false;
}

// Prevent deleting a movie if active tickets are still linked to it.
bool Registry::movieHasActiveTickets(const string& movieTitle) const {
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        if (toLowerText(ticket.movieTitle) == toLowerText(movieTitle)
            && ticket.status != TicketStatus::CANCELLED) {
            return true;
        }
    }
    return false;
}

// Return a modifiable ticket pointer for update operations.
Ticket* Registry::findTicketByID(int ticketID) {
    for (int index = 0; index < ticketCount; ++index) {
        Ticket& ticket = tickets[index];
        if (ticket.ticketID == ticketID) {
            return &ticket;
        }
    }
    return nullptr;
}

// Return read-only ticket pointer for search/display operations.
const Ticket* Registry::findTicketByID(int ticketID) const {
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        if (ticket.ticketID == ticketID) {
            return &ticket;
        }
    }
    return nullptr;
}

// Wrapper for linear search algorithm.
int Registry::linearSearchIndex(int ticketID, int& comparisons) const {
    return Finder::linearFind(tickets, ticketCount, ticketID, comparisons);
}

// Wrapper for binary search algorithm.
int Registry::binarySearchIndex(int ticketID, int& comparisons) const {
    return Finder::binaryFind(tickets, ticketCount, ticketID, comparisons);
}

// Copy ticket records into another array and sort by ticket ID using insertion sort.
void Registry::getTicketsSortedByID(Ticket sortedTickets[], int& comparisons, int& shifts) const {
    for (int index = 0; index < ticketCount; ++index) {
        sortedTickets[index] = tickets[index];
    }
    comparisons = 0;
    shifts = 0;

    for (int i = 1; i < ticketCount; ++i) {
        Ticket key = sortedTickets[i];
        int j = i;

        while (j > 0) {
            comparisons++;
            if (sortedTickets[j - 1].ticketID <= key.ticketID) {
                break;
            }
            sortedTickets[j] = sortedTickets[j - 1];
            shifts++;
            --j;
        }
        sortedTickets[j] = key;
    }
}

// Display detailed information for one ticket.
void Registry::displayTicketDetails(const Ticket& ticket) const {
    cout << "Customer Name: " << ticket.customerName << endl;
    cout << "Movie Title: " << ticket.movieTitle << endl;
    cout << "Genre: " << ticket.genre << endl;
    cout << "Classification: " << ticket.classification << endl;
    cout << "Language: " << ticket.language << endl;
    cout << "Hall: " << ticket.hallName << endl;
    cout << "Showtime: " << ticket.showTime << endl;
    cout << "Seat Code: " << ticket.seatCode << endl;
    cout << "Ticket Type: " << ticket.ticketType << endl;
    cout << fixed << setprecision(2);
    cout << "Ticket Price: RM" << ticket.ticketPrice << endl;
    cout << "Ticket ID: " << ticket.ticketID << endl;
    cout << "Status: " << ticketStatusToString(ticket.status) << endl;
}

// Numeric validation for ticket IDs.
int Registry::getValidatedTicketID(const string& prompt) const {
    while (true) {
        cout << prompt;
        int ticketID;
        if (!(cin >> ticketID)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a numeric ticket ID." << endl;
            continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (ticketID <= 0) {
            cout << "Invalid input. Ticket ID must be a positive number." << endl;
            continue;
        }
        return ticketID;
    }
}

// Text validation used by names, reasons, file names, movie titles, halls, and showtimes.
string Registry::getValidatedText(const string& prompt, const string& fieldName) const {
    while (true) {
        string value;
        cout << prompt;
        getline(cin, value);
        if (isValidText(value)) {
            return value;
        }
        cout << fieldName << " cannot be empty." << endl;
    }
}

// Let the user choose a movie from the catalog instead of typing the movie manually.
string Registry::getMovieTitleFromSelection() const {
    while (true) {
        movieCatalog.showMovies();
        cout << "Select movie number: ";
        int movieNumber;
        if (!(cin >> movieNumber)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a movie number." << endl;
            continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (!movieCatalog.isValidMovieNumber(movieNumber)) {
            cout << "Invalid movie number. Please select from the movie list." << endl;
            continue;
        }
        return movieCatalog.getMovieTitle(movieNumber);
    }
}

// Used during edit: user can choose a new movie or keep the current movie.
string Registry::getOptionalMovieTitleFromSelection(const string& currentMovieTitle) const {
    while (true) {
        movieCatalog.showMovies();
        cout << "Select new movie number, or 0 to keep current movie: ";
        int movieNumber;
        if (!(cin >> movieNumber)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a movie number." << endl;
            continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (movieNumber == 0) {
            return currentMovieTitle;
        }
        if (!movieCatalog.isValidMovieNumber(movieNumber)) {
            cout << "Invalid movie number. Please select from the movie list." << endl;
            continue;
        }
        return movieCatalog.getMovieTitle(movieNumber);
    }
}

// Validate seat format such as A1 or B10.
string Registry::getValidatedSeatCode() const {
    while (true) {
        string seatCode = getValidatedText("Enter seat code (example A1, B10): ", "Seat code");
        if (isValidSeatCode(seatCode)) {
            return seatCode;
        }
        cout << "Invalid seat format. Please use a letter followed by number, such as A1 or B10." << endl;
    }
}

// Ticket type selection also sets ticket price for revenue calculation.
void Registry::getTicketTypeFromSelection(string& ticketType, double& ticketPrice) const {
    while (true) {
        cout << "\nTicket Types" << endl;
        cout << "1. Adult - RM18.00" << endl;
        cout << "2. Student - RM12.00" << endl;
        cout << "3. Child - RM8.00" << endl;
        cout << "Select ticket type: ";

        int option;
        if (!(cin >> option)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a ticket type number." << endl;
            continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (option == 1) {
            ticketType = "Adult";
            ticketPrice = 18.00;
            return;
        }
        if (option == 2) {
            ticketType = "Student";
            ticketPrice = 12.00;
            return;
        }
        if (option == 3) {
            ticketType = "Child";
            ticketPrice = 8.00;
            return;
        }
        cout << "Invalid ticket type. Please select 1, 2, or 3." << endl;
    }
}

// Optional input for edit operation; empty input means keep current value.
string Registry::getOptionalText(const string& prompt) const {
    string value;
    cout << prompt;
    getline(cin, value);
    return value;
}

// Standard ticket ID prompt used by search/cancel/edit.
int Registry::getTicketIDFromInput() const {
    return getValidatedTicketID("Enter ticket ID: ");
}

// Insert a ticket into the ticket registry array.
void Registry::addTicketToRegistry(const Ticket& ticket) {
    if (ticketCount >= MaxTickets) {
        cout << "Cannot add ticket: ticket registry is full." << endl;
        return;
    }
    tickets[ticketCount] = ticket;
    ticketCount++;
}

// Rebuild queue after loading ticket records from text file.
void Registry::rebuildWaitingLine() {
    waitingLine.clearLine();
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        if (ticket.status == TicketStatus::WAITING) {
            waitingLine.joinLine(ticket);
        }
    }
}

// Print one compact ticket row to console or report file.
void Registry::printTicketLine(const Ticket& ticket, ostream& output) const {
    output << "  Ticket #" << ticket.ticketID << " | " << ticket.customerName
           << " | " << ticket.movieTitle << " | " << ticket.genre
           << " | " << ticket.classification << " | " << ticket.language
           << " | " << ticket.hallName
           << " | " << ticket.showTime << " | " << ticket.seatCode << " | " << ticket.ticketType
           << " | RM" << fixed << setprecision(2) << ticket.ticketPrice << " | "
           << ticketStatusToString(ticket.status);
}

// Print booking receipt immediately after a successful booking.
void Registry::printReceipt(const Ticket& ticket) const {
    cout << "\nBooking Receipt" << endl;
    cout << "Ticket ID: " << ticket.ticketID << endl;
    cout << "Customer: " << ticket.customerName << endl;
    cout << "Movie: " << ticket.movieTitle << endl;
    cout << "Genre: " << ticket.genre << endl;
    cout << "Classification: " << ticket.classification << endl;
    cout << "Language: " << ticket.language << endl;
    cout << "Hall: " << ticket.hallName << endl;
    cout << "Showtime: " << ticket.showTime << endl;
    cout << "Seat: " << ticket.seatCode << endl;
    cout << "Ticket Type: " << ticket.ticketType << endl;
    cout << fixed << setprecision(2);
    cout << "Price: RM" << ticket.ticketPrice << endl;
    cout << "Status: " << ticketStatusToString(ticket.status) << endl;
}

// Shared file-writing helper for both manual save and autosave.
bool Registry::saveTicketsToFile(const string& fileName, bool showMessage) const {
    ofstream outputFile(fileName);
    if (!outputFile) {
        if (showMessage) {
            cout << "Unable to open file for saving." << endl;
        }
        return false;
    }

    outputFile << "TicketID|CustomerName|MovieTitle|Genre|Classification|Language|Hall|Showtime|SeatCode|TicketType|TicketPrice|Status" << endl;
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        outputFile << ticket.ticketID << "|"
                   << ticket.customerName << "|"
                   << ticket.movieTitle << "|"
                   << ticket.genre << "|"
                   << ticket.classification << "|"
                   << ticket.language << "|"
                   << ticket.hallName << "|"
                   << ticket.showTime << "|"
                   << ticket.seatCode << "|"
                   << ticket.ticketType << "|"
                   << fixed << setprecision(2) << ticket.ticketPrice << "|"
                   << ticketStatusToString(ticket.status) << endl;
    }

    if (showMessage) {
        cout << "Tickets saved to " << fileName << "." << endl;
    }
    return true;
}

// Shared movie catalog file-writing helper for both manual save and autosave.
bool Registry::saveMovieCatalogToFile(const string& fileName, bool showMessage) const {
    ofstream outputFile(fileName);
    if (!outputFile) {
        if (showMessage) {
            cout << "Unable to open movie catalog file for saving." << endl;
        }
        return false;
    }

    outputFile << "MovieTitle|Genre|Classification|Language|Hall|Showtime" << endl;
    for (int movieNumber = 1; movieNumber <= movieCatalog.getMovieCount(); ++movieNumber) {
        outputFile << movieCatalog.getMovieTitle(movieNumber) << "|"
                   << movieCatalog.getGenre(movieNumber) << "|"
                   << movieCatalog.getClassification(movieNumber) << "|"
                   << movieCatalog.getLanguage(movieNumber) << "|"
                   << movieCatalog.getHallName(movieNumber) << "|"
                   << movieCatalog.getShowTime(movieNumber) << endl;
    }

    if (showMessage) {
        cout << "Movie catalog saved to " << fileName << "." << endl;
    }
    return true;
}

// Automatically save ticket records after every ticket-related change.
void Registry::autoSaveTickets() const {
    if (saveTicketsToFile("tickets_autosave.txt", false)) {
        cout << "Auto-saved ticket records to tickets_autosave.txt." << endl;
    }
}

// Automatically save movie catalog after every movie-related change.
void Registry::autoSaveMovieCatalog() const {
    if (saveMovieCatalogToFile("movies_autosave.txt", false)) {
        cout << "Auto-saved movie catalog to movies_autosave.txt." << endl;
    }
}

// Assignment Part A: Add customer to booking queue.
// Customer booking flow: validate input, create ticket, enqueue it, print receipt, and autosave.
void Registry::joinWaitingLine() {
    if (ticketCount >= MaxTickets) {
        cout << "Cannot join line: ticket registry is full." << endl;
        return;
    }

    int ticketID = getValidatedTicketID("Enter ticket ID: ");
    if (ticketIDExists(ticketID)) {
        cout << "Cannot join line: Ticket ID already exists in registry." << endl;
        return;
    }

    string customerName = getValidatedText("Enter customer name: ", "Customer name");
    string movieTitle = getMovieTitleFromSelection();
    string genre;
    string classification;
    string language;
    string hallName;
    string showTime;
    movieCatalog.findMovieDetailsByTitle(movieTitle, genre, classification, language, hallName, showTime);
    string seatCode = getValidatedSeatCode();
    if (seatCodeTaken(hallName, seatCode)) {
        cout << "Cannot join line: Seat " << seatCode << " is already taken in " << hallName << "." << endl;
        return;
    }
    string ticketType;
    double ticketPrice = 0.0;
    getTicketTypeFromSelection(ticketType, ticketPrice);

    Ticket ticket{ticketID, customerName, movieTitle, genre, classification, language, hallName, showTime, seatCode, ticketType, ticketPrice, TicketStatus::WAITING};
    addTicketToRegistry(ticket);
    if (waitingLine.joinLine(ticket)) {
        printReceipt(ticket);
        autoSaveTickets();
    }
}

// Assignment Part A: Serve/remove customer from queue using FIFO.
// Staff serves the front customer in FIFO order and updates ticket status.
void Registry::serveNextCustomer() {
    Ticket servedTicket;
    if (waitingLine.serveNext(servedTicket)) {
        Ticket* ticket = findTicketByID(servedTicket.ticketID);
        if (ticket != nullptr) {
            ticket->status = TicketStatus::SERVED;
            cout << "Ticket #" << ticket->ticketID << " status -> " << ticketStatusToString(ticket->status) << endl;
            autoSaveTickets();
        }
    }
}

void Registry::viewWaitingLine() const {
    waitingLine.showLine();
}

void Registry::viewFrontOfLine() const {
    waitingLine.showFront();
}

void Registry::viewRearOfLine() const {
    waitingLine.showRear();
}

// Assignment Part A: Check whether queue is empty/full.
// Display whether the waiting-line queue is empty or full.
void Registry::viewQueueStatus() const {
    cout << "\nQueue Status" << endl;
    cout << "Is empty: " << (waitingLine.isEmpty() ? "Yes" : "No") << endl;
    cout << "Is full: " << (waitingLine.isFull() ? "Yes" : "No") << endl;
}

// Assignment Part B: Push cancellation record into stack.
// Customer cancellation flow: remove from queue, push to cancellation stack, then autosave.
void Registry::cancelTicket() {
    int ticketID = getTicketIDFromInput();
    Ticket* ticket = findTicketByID(ticketID);
    if (ticket == nullptr) {
        cout << "Ticket ID not found in registry." << endl;
        return;
    }
    if (ticket->status == TicketStatus::CANCELLED) {
        cout << "Ticket #" << ticketID << " is already cancelled." << endl;
        return;
    }
    if (ticket->status == TicketStatus::SERVED) {
        cout << "Ticket #" << ticketID << " has already been served and cannot be cancelled." << endl;
        return;
    }

    if (waitingLine.removeTicketByID(ticketID)) {
        cout << "Removed Ticket #" << ticketID << " from waiting line for cancellation." << endl;
    }

    string reason = getValidatedText("Enter cancellation reason: ", "Cancellation reason");
    ticket->status = TicketStatus::CANCELLED;
    CancelEntry entry{ticketID, ticket->customerName, reason, getCurrentTimestamp()};
    if (cancelLog.recordCancel(entry)) {
        cout << "Ticket #" << ticketID << " status -> " << ticketStatusToString(ticket->status) << endl;
        autoSaveTickets();
    } else {
        ticket->status = TicketStatus::WAITING;
        cout << "Cancellation failed. Ticket #" << ticketID << " reverted to WAITING." << endl;
        waitingLine.joinLine(*ticket);
    }
}

// Assignment Part B: Undo latest cancellation using Pop.
// Undo the latest cancellation by popping from the cancellation stack.
void Registry::undoLastCancellation() {
    CancelEntry entry;
    if (!cancelLog.undoCancel(entry)) {
        return;
    }

    Ticket* ticket = findTicketByID(entry.ticketID);
    if (ticket == nullptr) {
        cout << "Error: ticket record not found while undoing cancellation." << endl;
        return;
    }

    ticket->status = TicketStatus::WAITING;
    waitingLine.joinLine(*ticket);
    cout << "Ticket #" << ticket->ticketID << " status -> " << ticketStatusToString(ticket->status) << endl;
    autoSaveTickets();
}

void Registry::viewCancellationLog() const {
    cancelLog.showAllCancels();
}

void Registry::peekLatestCancellation() const {
    CancelEntry entry;
    cancelLog.peekLatest(entry);
}

// Assignment Part C: Linear Search by Booking/Ticket ID.
// Linear search feature shown in Search Ticket submenu.
void Registry::findTicketLinear() const {
    int ticketID = getTicketIDFromInput();
    int comparisons = 0;
    int index = linearSearchIndex(ticketID, comparisons);
    if (index >= 0) {
        cout << "Ticket found after " << comparisons << " comparisons." << endl;
        displayTicketDetails(tickets[index]);
    } else {
        cout << "No ticket found with that ID." << endl;
    }
}

// Assignment Part C: Binary Search by Booking/Ticket ID.
// Binary search feature shown in Search Ticket submenu.
void Registry::findTicketBinary() const {
    int ticketID = getTicketIDFromInput();
    int comparisons = 0;
    int index = binarySearchIndex(ticketID, comparisons);
    if (index >= 0) {
        cout << "Ticket found after " << comparisons << " comparisons in sorted copy." << endl;
        Ticket sortedTickets[MaxTickets];
        int sortComparisons = 0;
        int shifts = 0;
        getTicketsSortedByID(sortedTickets, sortComparisons, shifts);
        displayTicketDetails(sortedTickets[index]);
    } else {
        cout << "No ticket found with that ID." << endl;
    }
}

// Assignment Part D: Compare Linear Search and Binary Search.
// Run both search algorithms and compare their number of comparisons.
void Registry::compareLinearVsBinary() const {
    int ticketID = getTicketIDFromInput();
    int linearComparisons = 0;
    int binaryComparisons = 0;
    int linearIndex = linearSearchIndex(ticketID, linearComparisons);
    int binaryIndex = binarySearchIndex(ticketID, binaryComparisons);

    cout << "\nSearch comparison for Ticket ID " << ticketID << ":" << endl;
    if (linearIndex >= 0) {
        cout << "  Linear search found the ticket after " << linearComparisons << " comparisons." << endl;
    } else {
        cout << "  Linear search did not find the ticket after " << linearComparisons << " comparisons." << endl;
    }
    if (binaryIndex >= 0) {
        cout << "  Binary search found the ticket after " << binaryComparisons << " comparisons." << endl;
    } else {
        cout << "  Binary search did not find the ticket after " << binaryComparisons << " comparisons." << endl;
    }

    cout << "  Big-O: Linear O(n), Binary O(log n) with sort overhead." << endl;
    if (linearIndex >= 0 && binaryIndex >= 0) {
        if (linearComparisons < binaryComparisons) {
            cout << "  Verdict: Linear search was faster on this dataset." << endl;
        } else if (binaryComparisons < linearComparisons) {
            cout << "  Verdict: Binary search was faster on this dataset." << endl;
        } else {
            cout << "  Verdict: Both searches used the same number of comparisons on this dataset." << endl;
        }
    } else if (linearIndex >= 0) {
        cout << "  Verdict: Only linear search found the ticket in this dataset." << endl;
    } else if (binaryIndex >= 0) {
        cout << "  Verdict: Only binary search found the ticket in this dataset." << endl;
    } else {
        cout << "  Verdict: Neither search found the ticket." << endl;
    }

    Finder::printComparisonTable(linearComparisons, binaryComparisons);
}

// Display every ticket stored in the ticket registry array.
void Registry::viewFullRegistry() const {
    if (ticketCount == 0) {
        cout << "Full ticket registry is empty." << endl;
        return;
    }

    cout << "Full ticket registry (all tickets):" << endl;
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        printTicketLine(ticket, cout);
        cout << endl;
    }
}

// Display summary counts and active revenue.
void Registry::viewSystemSummary() const {
    int waitingCount = 0;
    int servedCount = 0;
    int cancelledCount = 0;
    double totalRevenue = 0.0;

    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        if (ticket.status == TicketStatus::WAITING) {
            waitingCount++;
            totalRevenue += ticket.ticketPrice;
        } else if (ticket.status == TicketStatus::SERVED) {
            servedCount++;
            totalRevenue += ticket.ticketPrice;
        } else if (ticket.status == TicketStatus::CANCELLED) {
            cancelledCount++;
        }
    }

    cout << "\nSystem Summary" << endl;
    cout << "Total tickets: " << ticketCount << endl;
    cout << "Waiting tickets: " << waitingCount << endl;
    cout << "Served tickets: " << servedCount << endl;
    cout << "Cancelled tickets: " << cancelledCount << endl;
    cout << "Cancellations in log: " << cancelLog.getCount() << endl;
    cout << fixed << setprecision(2);
    cout << "Total active revenue: RM" << totalRevenue << endl;
}

// Binary search needs sorted data, so insertion sort is used to sort ticket IDs.
// Display sorted tickets using insertion sort.
void Registry::viewTicketsSortedByID() const {
    if (ticketCount == 0) {
        cout << "No tickets available to sort." << endl;
        return;
    }

    int comparisons = 0;
    int shifts = 0;
    Ticket sortedTickets[MaxTickets];
    getTicketsSortedByID(sortedTickets, comparisons, shifts);

    cout << "Tickets sorted by Ticket ID using insertion sort:" << endl;
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = sortedTickets[index];
        printTicketLine(ticket, cout);
        cout << endl;
    }
    cout << "Insertion sort comparisons: " << comparisons << endl;
    cout << "Insertion sort shifts: " << shifts << endl;
}

// Staff/customer display of movie catalog.
void Registry::viewMovieList() const {
    movieCatalog.showMovies();
}

// Customer-friendly showtime display.
void Registry::viewTodaysShowtimes() const {
    movieCatalog.showTodaysShowtimes();
}

// Staff adds movie information into the movie catalog array.
void Registry::addMovie() {
    string movieTitle = getValidatedText("Enter new movie title: ", "Movie title");
    string genre = getValidatedText("Enter genre: ", "Genre");
    string classification = getValidatedText("Enter classification (U/P12/P13/P16/P18): ", "Classification");
    string language = getValidatedText("Enter language: ", "Language");
    string hallName = getValidatedText("Enter hall name: ", "Hall name");
    string showTime = getValidatedText("Enter showtime for today: ", "Showtime");

    if (movieCatalog.addMovie(movieTitle, genre, classification, language, hallName, showTime)) {
        cout << "Movie added successfully: " << movieTitle << " (" << hallName
             << ", " << showTime << ")" << endl;
        autoSaveMovieCatalog();
    }
}

// Staff deletes a movie if no active tickets depend on it.
void Registry::deleteMovie() {
    movieCatalog.showMovies();
    cout << "Enter movie number to delete: ";
    int movieNumber;
    if (!(cin >> movieNumber)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input. Please enter a movie number." << endl;
        return;
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    if (!movieCatalog.isValidMovieNumber(movieNumber)) {
        cout << "Invalid movie number. Please select from the movie list." << endl;
        return;
    }

    string movieTitle = movieCatalog.getMovieTitle(movieNumber);
    if (movieHasActiveTickets(movieTitle)) {
        cout << "Cannot delete movie: active tickets exist for " << movieTitle << "." << endl;
        return;
    }

    if (movieCatalog.removeMovie(movieNumber)) {
        cout << "Movie deleted successfully: " << movieTitle << endl;
        autoSaveMovieCatalog();
    }
}

// Staff edits ticket information and keeps queue data synchronized.
void Registry::editTicketInfo() {
    int ticketID = getTicketIDFromInput();
    Ticket* ticket = findTicketByID(ticketID);
    if (ticket == nullptr) {
        cout << "Ticket ID not found in registry." << endl;
        return;
    }
    if (ticket->status == TicketStatus::CANCELLED) {
        cout << "Cancelled tickets cannot be edited. Undo the cancellation first if needed." << endl;
        return;
    }

    cout << "Current ticket details:" << endl;
    displayTicketDetails(*ticket);
    cout << "Press Enter without typing anything to keep the current value." << endl;

    string newCustomerName = getOptionalText("New customer name: ");
    if (isValidText(newCustomerName)) {
        ticket->customerName = newCustomerName;
    }

    string updatedMovieTitle = getOptionalMovieTitleFromSelection(ticket->movieTitle);
    string updatedGenre;
    string updatedClassification;
    string updatedLanguage;
    string updatedHallName;
    string updatedShowTime;
    movieCatalog.findMovieDetailsByTitle(updatedMovieTitle, updatedGenre, updatedClassification,
                                         updatedLanguage, updatedHallName, updatedShowTime);

    string newSeatCode = getOptionalText("New seat code: ");
    string updatedSeatCode = ticket->seatCode;
    if (isValidText(newSeatCode)) {
        if (!isValidSeatCode(newSeatCode)) {
            cout << "Cannot update ticket: invalid seat format. Use a letter followed by number, such as A1 or B10." << endl;
            return;
        }
        updatedSeatCode = newSeatCode;
    }
    if (seatCodeTakenByOtherTicket(updatedHallName, updatedSeatCode, ticketID)) {
        cout << "Cannot update ticket: Seat " << updatedSeatCode << " is already taken in "
             << updatedHallName << "." << endl;
        return;
    }

    ticket->movieTitle = updatedMovieTitle;
    ticket->genre = updatedGenre;
    ticket->classification = updatedClassification;
    ticket->language = updatedLanguage;
    ticket->hallName = updatedHallName;
    ticket->showTime = updatedShowTime;
    ticket->seatCode = updatedSeatCode;

    string updateTicketType = getOptionalText("Update ticket type? Enter Y for yes, or press Enter to keep current type: ");
    string updateAnswer = toLowerText(updateTicketType);
    if (updateAnswer == "y" || updateAnswer == "yes") {
        getTicketTypeFromSelection(ticket->ticketType, ticket->ticketPrice);
    }

    if (ticket->status == TicketStatus::WAITING) {
        waitingLine.updateTicketByID(*ticket);
    }
    cout << "Ticket #" << ticketID << " updated successfully." << endl;
    autoSaveTickets();
}

// Manual ticket save with user-selected file name.
void Registry::saveTicketsToTextFile() const {
    string fileName = getValidatedText("Enter text file name to save: ", "File name");
    saveTicketsToFile(fileName, true);
}

// Manual ticket load from text file; invalid rows are skipped.
void Registry::loadTicketsFromTextFile() {
    string fileName = getValidatedText("Enter text file name to load: ", "File name");
    ifstream inputFile(fileName);
    if (!inputFile) {
        cout << "Unable to open file for loading." << endl;
        return;
    }

    Ticket loadedTickets[MaxTickets];
    string line;
    int lineNumber = 0;
    int loadedCount = 0;
    int skippedCount = 0;

    while (getline(inputFile, line)) {
        lineNumber++;
        if (lineNumber == 1 && line == "TicketID|CustomerName|MovieTitle|Genre|Classification|Language|Hall|Showtime|SeatCode|TicketType|TicketPrice|Status") {
            continue;
        }
        if (!isValidText(line)) {
            continue;
        }

        stringstream lineStream(line);
        string idText;
        string customerName;
        string movieTitle;
        string genre;
        string classification;
        string language;
        string hallName;
        string showTime;
        string seatCode;
        string ticketType;
        string ticketPriceText;
        string statusText;

        getline(lineStream, idText, '|');
        getline(lineStream, customerName, '|');
        getline(lineStream, movieTitle, '|');
        getline(lineStream, genre, '|');
        getline(lineStream, classification, '|');
        getline(lineStream, language, '|');
        getline(lineStream, hallName, '|');
        getline(lineStream, showTime, '|');
        getline(lineStream, seatCode, '|');
        getline(lineStream, ticketType, '|');
        getline(lineStream, ticketPriceText, '|');
        getline(lineStream, statusText, '|');

        string extraText;
        bool hasExtraColumn = static_cast<bool>(getline(lineStream, extraText, '|'));
        TicketStatus status;
        int ticketID = 0;
        double ticketPrice = 0.0;
        stringstream idStream(idText);
        stringstream priceStream(ticketPriceText);

        bool invalidLine = hasExtraColumn
            || !(idStream >> ticketID)
            || !(priceStream >> ticketPrice)
            || ticketID <= 0
            || ticketPrice <= 0.0
            || !isValidText(customerName)
            || !isValidText(movieTitle)
            || !isValidText(genre)
            || !isValidText(classification)
            || !isValidText(language)
            || !isValidText(hallName)
            || !isValidText(showTime)
            || !isValidText(seatCode)
            || !isValidSeatCode(seatCode)
            || !isValidText(ticketType)
            || !stringToTicketStatus(statusText, status);

        if (!invalidLine) {
            for (int index = 0; index < loadedCount; ++index) {
                const Ticket& loadedTicket = loadedTickets[index];
                if (loadedTicket.ticketID == ticketID) {
                    invalidLine = true;
                    break;
                }
                if (loadedTicket.status != TicketStatus::CANCELLED
                    && status != TicketStatus::CANCELLED
                    && toLowerText(loadedTicket.hallName) == toLowerText(hallName)
                    && toLowerText(loadedTicket.seatCode) == toLowerText(seatCode)) {
                    invalidLine = true;
                    break;
                }
            }
        }

        if (invalidLine) {
            skippedCount++;
            continue;
        }

        if (loadedCount >= MaxTickets) {
            skippedCount++;
            continue;
        }

        loadedTickets[loadedCount] = Ticket{ticketID, customerName, movieTitle, genre, classification, language, hallName, showTime, seatCode, ticketType, ticketPrice, status};
        loadedCount++;
    }

    for (int index = 0; index < loadedCount; ++index) {
        tickets[index] = loadedTickets[index];
    }
    ticketCount = loadedCount;
    cancelLog = CancelLog();
    rebuildWaitingLine();

    cout << "Loaded " << loadedCount << " ticket(s) from " << fileName << "." << endl;
    if (skippedCount > 0) {
        cout << "Skipped " << skippedCount << " invalid row(s)." << endl;
    }
    cout << "Cancellation log reset after file load." << endl;
    autoSaveTickets();
}

// Manual movie catalog save with user-selected file name.
void Registry::saveMovieCatalogToTextFile() const {
    string fileName = getValidatedText("Enter movie catalog file name to save: ", "File name");
    saveMovieCatalogToFile(fileName, true);
}

// Manual movie catalog load. It is blocked when tickets already exist to avoid mismatched data.
void Registry::loadMovieCatalogFromTextFile() {
    if (ticketCount > 0) {
        cout << "Cannot load movie catalog while ticket registry is not empty." << endl;
        return;
    }

    string fileName = getValidatedText("Enter movie catalog file name to load: ", "File name");
    ifstream inputFile(fileName);
    if (!inputFile) {
        cout << "Unable to open movie catalog file for loading." << endl;
        return;
    }

    MovieCatalog loadedCatalog;
    loadedCatalog.clearMovies();

    string line;
    int lineNumber = 0;
    int loadedCount = 0;
    int skippedCount = 0;

    while (getline(inputFile, line)) {
        lineNumber++;
        if (lineNumber == 1 && line == "MovieTitle|Genre|Classification|Language|Hall|Showtime") {
            continue;
        }
        if (!isValidText(line)) {
            continue;
        }

        stringstream lineStream(line);
        string movieTitle;
        string genre;
        string classification;
        string language;
        string hallName;
        string showTime;
        string extraText;

        getline(lineStream, movieTitle, '|');
        getline(lineStream, genre, '|');
        getline(lineStream, classification, '|');
        getline(lineStream, language, '|');
        getline(lineStream, hallName, '|');
        getline(lineStream, showTime, '|');
        bool hasExtraColumn = static_cast<bool>(getline(lineStream, extraText, '|'));

        if (hasExtraColumn || !isValidText(movieTitle) || !isValidText(genre)
            || !isValidText(classification) || !isValidText(language)
            || !isValidText(hallName) || !isValidText(showTime)) {
            skippedCount++;
            continue;
        }

        if (loadedCatalog.addMovie(movieTitle, genre, classification, language, hallName, showTime)) {
            loadedCount++;
        } else {
            skippedCount++;
        }
    }

    movieCatalog = loadedCatalog;
    cout << "Loaded " << loadedCount << " movie(s) from " << fileName << "." << endl;
    if (skippedCount > 0) {
        cout << "Skipped " << skippedCount << " invalid movie row(s)." << endl;
    }
    autoSaveMovieCatalog();
}

// Export a formatted report containing summary, revenue, and sorted ticket records.
void Registry::exportReport() const {
    string fileName = getValidatedText("Enter report file name to export: ", "File name");
    ofstream outputFile(fileName);
    if (!outputFile) {
        cout << "Unable to open report file." << endl;
        return;
    }

    int waitingCount = 0;
    int servedCount = 0;
    int cancelledCount = 0;
    double totalRevenue = 0.0;
    for (int index = 0; index < ticketCount; ++index) {
        const Ticket& ticket = tickets[index];
        if (ticket.status == TicketStatus::WAITING) {
            waitingCount++;
            totalRevenue += ticket.ticketPrice;
        } else if (ticket.status == TicketStatus::SERVED) {
            servedCount++;
            totalRevenue += ticket.ticketPrice;
        } else if (ticket.status == TicketStatus::CANCELLED) {
            cancelledCount++;
        }
    }

    int comparisons = 0;
    int shifts = 0;
    Ticket sortedTickets[MaxTickets];
    getTicketsSortedByID(sortedTickets, comparisons, shifts);

    outputFile << "MovieHouse Booking Manager Report" << endl;
    outputFile << "Generated At: " << getCurrentTimestamp() << endl << endl;
    outputFile << "System Summary" << endl;
    outputFile << "Total tickets: " << ticketCount << endl;
    outputFile << "Waiting tickets: " << waitingCount << endl;
    outputFile << "Served tickets: " << servedCount << endl;
    outputFile << "Cancelled tickets: " << cancelledCount << endl;
    outputFile << "Cancellations in log: " << cancelLog.getCount() << endl << endl;
    outputFile << fixed << setprecision(2);
    outputFile << "Total active revenue: RM" << totalRevenue << endl << endl;

    outputFile << "Tickets Sorted by Ticket ID" << endl;
    if (ticketCount == 0) {
        outputFile << "No tickets available." << endl;
    } else {
        for (int index = 0; index < ticketCount; ++index) {
            const Ticket& ticket = sortedTickets[index];
            printTicketLine(ticket, outputFile);
            outputFile << endl;
        }
    }
    outputFile << endl;
    outputFile << "Searching Algorithm Comparison" << endl;
    outputFile << "Linear Search: O(n), checks records one by one and does not need sorted data." << endl;
    outputFile << "Binary Search: O(log n), faster on sorted data but requires ticket IDs to be sorted first." << endl;
    outputFile << "For small unsorted data, linear search is simpler. For large sorted data, binary search performs better." << endl << endl;

    outputFile << "Sorting Algorithm: Insertion Sort" << endl;
    outputFile << "Insertion sort comparisons: " << comparisons << endl;
    outputFile << "Insertion sort shifts: " << shifts << endl;

    cout << "Report exported to " << fileName << "." << endl;
}
