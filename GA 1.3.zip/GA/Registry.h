#ifndef REGISTRY_H
#define REGISTRY_H

#include "CancelLog.h"
#include "Finder.h"
#include "MovieCatalog.h"
#include "Ticket.h"
#include "WaitingLine.h"

#include <iostream>
#include <string>

using namespace std;

// Assignment controller class.
// It combines Part A Queue, Part B Stack, Part C Searching, Part D Comparison,
// validation, file handling, and report generation.
// Registry is the main controller class.
// It connects the ticket array, waiting-line queue, cancellation stack, and movie catalog.
class Registry {
public:
    // Maximum number of ticket records stored in the ticket registry array.
    static const int MaxTickets = 100;

    Registry();

    void joinWaitingLine();
    void serveNextCustomer();
    void viewWaitingLine() const;
    void viewFrontOfLine() const;
    void viewRearOfLine() const;
    void viewQueueStatus() const;
    void cancelTicket();
    void undoLastCancellation();
    void viewCancellationLog() const;
    void peekLatestCancellation() const;
    void findTicketLinear() const;
    void findTicketBinary() const;
    void compareLinearVsBinary() const;
    void viewFullRegistry() const;
    void viewSystemSummary() const;
    void viewTicketsSortedByID() const;
    void viewMovieList() const;
    void viewTodaysShowtimes() const;
    void viewSeatMap() const;
    void addMovie();
    void deleteMovie();
    void editTicketInfo();
    void saveTicketsToTextFile() const;
    void loadTicketsFromTextFile();
    void saveMovieCatalogToTextFile() const;
    void loadMovieCatalogFromTextFile();
    void exportReport() const;

private:
    // Ticket registry implemented using array + count.
    Ticket tickets[MaxTickets];
    int ticketCount;

    // Main data structure modules used by the system.
    WaitingLine waitingLine;
    CancelLog cancelLog;
    MovieCatalog movieCatalog;

    bool ticketIDExists(int ticketID) const;
    bool seatCodeTaken(const string& hallName, const string& seatCode) const;
    bool seatCodeTakenByOtherTicket(const string& hallName, const string& seatCode, int currentTicketID) const;
    bool seatCodeInsideSeatMap(const string& seatCode) const;
    bool movieHasActiveTickets(const string& movieTitle) const;
    Ticket* findTicketByID(int ticketID);
    const Ticket* findTicketByID(int ticketID) const;
    int linearSearchIndex(int ticketID, int& comparisons) const;
    int binarySearchIndex(int ticketID, int& comparisons) const;
    void getTicketsSortedByID(Ticket sortedTickets[], int& comparisons, int& shifts) const;
    void displayTicketDetails(const Ticket& ticket) const;
    int getValidatedTicketID(const string& prompt) const;
    string getMovieTitleFromSelection() const;
    string getOptionalMovieTitleFromSelection(const string& currentMovieTitle) const;
    string getValidatedSeatCode() const;
    void getTicketTypeFromSelection(string& ticketType, double& ticketPrice) const;
    string getValidatedText(const string& prompt, const string& fieldName) const;
    string getOptionalText(const string& prompt) const;
    int getTicketIDFromInput() const;
    void addTicketToRegistry(const Ticket& ticket);
    void rebuildWaitingLine();
    void printTicketLine(const Ticket& ticket, ostream& output) const;
    void printReceipt(const Ticket& ticket) const;
    void displaySeatMapForHall(const string& hallName) const;
    bool saveTicketsToFile(const string& fileName, bool showMessage) const;
    bool saveMovieCatalogToFile(const string& fileName, bool showMessage) const;
    void autoSaveTickets() const;
    void autoSaveMovieCatalog() const;
};

#endif // REGISTRY_H
