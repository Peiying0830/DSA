#include "Registry.h"

#include <iostream>
#include <limits>

using namespace std;

const string AdminPassword = "admin123";

// Display the first message shown when the program starts.
void displayWelcomeMessage() {
    cout << "\n========================================" << endl;
    cout << " Welcome to MovieHouse Booking Manager" << endl;
    cout << "========================================" << endl;
    cout << "Today's movies, halls, showtimes, tickets, and records are managed here." << endl;
}

// First-level menu for RBAC role selection.
void displayRoleMenu() {
    cout << "\nSelect User Role" << endl;
    cout << "1. Customer" << endl;
    cout << "2. Staff / Admin" << endl;
    cout << "3. Exit" << endl;
    cout << "Select an option: ";
}

// Customer menu contains public booking actions from the assignment scenario.
void displayCustomerMenu() {
    cout << "\nCustomer Menu" << endl;
    cout << "1. View Today's Showtimes" << endl;
    cout << "2. View Seat Map" << endl;
    cout << "3. Book Ticket / Join Waiting Line" << endl;
    cout << "4. Search Ticket" << endl;
    cout << "5. Cancel Ticket" << endl;
    cout << "6. Back to Role Menu" << endl;
    cout << "Select an option: ";
}

// Staff/Admin menu contains management features for queue, stack, search, records, and files.
void displayStaffMenu() {
    cout << "\nStaff / Admin Menu" << endl;
    cout << "1. Serve Next Customer" << endl;
    cout << "2. Undo Last Cancellation" << endl;
    cout << "3. View Records" << endl;
    cout << "4. Search Ticket" << endl;
    cout << "5. Edit Ticket Info" << endl;
    cout << "6. Movie Management" << endl;
    cout << "7. File Management" << endl;
    cout << "8. Back to Role Menu" << endl;
    cout << "Select an option: ";
}

void displaySearchMenu() {
    cout << "\nSearch Ticket" << endl;
    cout << "1. Linear Search" << endl;
    cout << "2. Binary Search" << endl;
    cout << "3. Compare Linear vs Binary Search" << endl;
    cout << "4. Back" << endl;
    cout << "Select an option: ";
}

void displayRecordsMenu() {
    cout << "\nView Records" << endl;
    cout << "1. Waiting Line Details" << endl;
    cout << "2. Queue Status" << endl;
    cout << "3. Cancellation Records" << endl;
    cout << "4. Full Ticket Registry" << endl;
    cout << "5. System Summary" << endl;
    cout << "6. Tickets Sorted by Ticket ID" << endl;
    cout << "7. Today's Showtimes" << endl;
    cout << "8. Back" << endl;
    cout << "Select an option: ";
}

void displayMovieMenu() {
    cout << "\nMovie Management" << endl;
    cout << "1. View Movie List" << endl;
    cout << "2. Add Movie" << endl;
    cout << "3. Delete Movie" << endl;
    cout << "4. Back" << endl;
    cout << "Select an option: ";
}

void displayFileMenu() {
    cout << "\nFile Management" << endl;
    cout << "1. Save Tickets to Text File" << endl;
    cout << "2. Load Tickets from Text File" << endl;
    cout << "3. Save Movie Catalog to Text File" << endl;
    cout << "4. Load Movie Catalog from Text File" << endl;
    cout << "5. Export Report" << endl;
    cout << "6. Back" << endl;
    cout << "Select an option: ";
}

// Reusable input validation for all menus.
int getMenuSelection(int minimumOption, int maximumOption) {
    while (true) {
        int choice;
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number between "
                 << minimumOption << " and " << maximumOption << "." << endl;
            continue;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (choice < minimumOption || choice > maximumOption) {
            cout << "Invalid option. Please select a number between "
                 << minimumOption << " and " << maximumOption << "." << endl;
            continue;
        }
        return choice;
    }
}

// Simple fixed-password check for Staff/Admin access.
bool verifyAdminPassword() {
    string password;
    cout << "Enter admin password: ";
    getline(cin, password);

    if (password == AdminPassword) {
        cout << "Access granted. Welcome, Staff/Admin." << endl;
        return true;
    }

    cout << "Access denied. Returning to role menu." << endl;
    return false;
}

// Assignment Part C and Part D:
// Search submenu lets user choose Linear Search, Binary Search, or comparison.
void handleSearchMenu(Registry& registry) {
    bool searching = true;
    while (searching) {
        displaySearchMenu();
        int option = getMenuSelection(1, 4);

        switch (option) {
            case 1:
                registry.findTicketLinear();
                break;
            case 2:
                registry.findTicketBinary();
                break;
            case 3:
                registry.compareLinearVsBinary();
                break;
            case 4:
                searching = false;
                break;
        }
    }
}

// Assignment display requirements:
// This submenu groups queue display, stack display, booking records, summary, and sorted records.
void handleRecordsMenu(Registry& registry) {
    bool viewing = true;
    while (viewing) {
        displayRecordsMenu();
        int option = getMenuSelection(1, 8);

        switch (option) {
            case 1:
                registry.viewWaitingLine();
                registry.viewFrontOfLine();
                registry.viewRearOfLine();
                break;
            case 2:
                registry.viewQueueStatus();
                break;
            case 3:
                registry.viewCancellationLog();
                registry.peekLatestCancellation();
                break;
            case 4:
                registry.viewFullRegistry();
                break;
            case 5:
                registry.viewSystemSummary();
                break;
            case 6:
                registry.viewTicketsSortedByID();
                break;
            case 7:
                registry.viewTodaysShowtimes();
                break;
            case 8:
                viewing = false;
                break;
        }
    }
}

// Staff movie management submenu for catalog maintenance.
void handleMovieMenu(Registry& registry) {
    bool managingMovies = true;
    while (managingMovies) {
        displayMovieMenu();
        int option = getMenuSelection(1, 4);

        switch (option) {
            case 1:
                registry.viewMovieList();
                break;
            case 2:
                registry.addMovie();
                break;
            case 3:
                registry.deleteMovie();
                break;
            case 4:
                managingMovies = false;
                break;
        }
    }
}

// Staff file management submenu for manual save/load/export operations.
void handleFileMenu(Registry& registry) {
    bool managingFiles = true;
    while (managingFiles) {
        displayFileMenu();
        int option = getMenuSelection(1, 6);

        switch (option) {
            case 1:
                registry.saveTicketsToTextFile();
                break;
            case 2:
                registry.loadTicketsFromTextFile();
                break;
            case 3:
                registry.saveMovieCatalogToTextFile();
                break;
            case 4:
                registry.loadMovieCatalogFromTextFile();
                break;
            case 5:
                registry.exportReport();
                break;
            case 6:
                managingFiles = false;
                break;
        }
    }
}

// Customer role workflow.
void handleCustomerMenu(Registry& registry) {
    bool customerActive = true;
    while (customerActive) {
        displayCustomerMenu();
        int option = getMenuSelection(1, 6);

        switch (option) {
            case 1:
                registry.viewTodaysShowtimes();
                break;
            case 2:
                registry.viewSeatMap();
                break;
            case 3:
                registry.joinWaitingLine();
                break;
            case 4:
                handleSearchMenu(registry);
                break;
            case 5:
                registry.cancelTicket();
                break;
            case 6:
                customerActive = false;
                break;
        }
    }
}

// Staff/Admin role workflow.
void handleStaffMenu(Registry& registry) {
    bool staffActive = true;
    while (staffActive) {
        displayStaffMenu();
        int option = getMenuSelection(1, 8);

        switch (option) {
            case 1:
                registry.serveNextCustomer();
                break;
            case 2:
                registry.undoLastCancellation();
                break;
            case 3:
                handleRecordsMenu(registry);
                break;
            case 4:
                handleSearchMenu(registry);
                break;
            case 5:
                registry.editTicketInfo();
                break;
            case 6:
                handleMovieMenu(registry);
                break;
            case 7:
                handleFileMenu(registry);
                break;
            case 8:
                staffActive = false;
                break;
        }
    }
}

int main() {
    Registry registry;
    bool running = true;

    displayWelcomeMessage();

    while (running) {
        displayRoleMenu();
        int option = getMenuSelection(1, 3);

        switch (option) {
            case 1:
                handleCustomerMenu(registry);
                break;
            case 2:
                if (verifyAdminPassword()) {
                    handleStaffMenu(registry);
                }
                break;
            case 3:
                cout << "Thank you for using MovieHouse Booking Manager. Goodbye!" << endl;
                running = false;
                break;
        }
    }

    return 0;
}
